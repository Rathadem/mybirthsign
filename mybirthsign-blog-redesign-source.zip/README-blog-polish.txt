MyBirthSign blog redesign source pack

Files:
- blog-polish.css: new blog-only stylesheet with image-led hero, gold zodiac-ring ornament, editorial cards, zodiac tiles, mobile breakpoints, and focus/reduced-motion styling.
- apply_blog_redesign.py: idempotent script that modifies only blog.html and creates css/blog-polish.css.

To apply in a local checkout of Rathadem/mybirthsign:
1. Copy blog-polish.css and apply_blog_redesign.py into the repository root.
2. Open a terminal at the repository root and run: python apply_blog_redesign.py
3. Inspect `git diff -- blog.html css/blog-polish.css`.
4. Run `node scripts/build-site.mjs` and inspect the EN, KM, and ZH output locally.
5. Keep the change on a separate preview branch. Do not merge to main or deploy production before approval.

The script is idempotent. It preserves the existing head metadata, AdSense markup, nav, current daily-fortune card, popular guide links, zodiac data, and educational section. It adds a translated Latest Articles row pointing only to existing article URLs.
