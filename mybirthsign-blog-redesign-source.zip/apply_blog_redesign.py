#!/usr/bin/env python3
"""Safely apply the MyBirthSign blog visual polish to a local repository checkout.

Run from the repository root: python apply_blog_redesign.py
It edits only blog.html and creates css/blog-polish.css. It is idempotent.
"""
from pathlib import Path
import re
import sys

ROOT = Path.cwd()
BLOG = ROOT / "blog.html"
CSS_SOURCE = Path(__file__).resolve().with_name("blog-polish.css")
CSS_TARGET = ROOT / "css" / "blog-polish.css"

if not BLOG.is_file():
    sys.exit("ERROR: Run this script from the MyBirthSign repository root (blog.html not found).")
if not CSS_SOURCE.is_file():
    sys.exit("ERROR: blog-polish.css must be beside this script.")

html = BLOG.read_text(encoding="utf-8")
original = html

# Add a page-specific stylesheet; global CSS and all other pages remain untouched.
link = '<link rel="stylesheet" href="css/blog-polish.css">'
if link not in html:
    anchor = '<link rel="stylesheet" href="css/style.css">'
    if html.count(anchor) != 1:
        sys.exit("ERROR: Expected exactly one main style.css link in blog.html; no changes written.")
    html = html.replace(anchor, anchor + "\n" + link, 1)

LATEST = {
    "en": '''<section class="bv2-section bv2-latest-section" id="latest-articles">
  <div class="bv2-section-head">
    <h2>Latest Articles</h2>
    <a class="bv2-view-all" href="blog.html">View All Articles →</a>
  </div>
  <div class="bv2-latest-grid">
    <a class="bv2-latest-card" href="blog/five-elements-explained.html"><img src="images/guides/five-elements.webp" alt="The five elements in Chinese zodiac tradition" loading="lazy" width="440" height="260"><div class="bv2-latest-body"><p class="bv2-latest-kicker">Zodiac Basics</p><h3>The Five Elements in Chinese Zodiac</h3><p>Learn how Wood, Fire, Earth, Metal, and Water add another layer to zodiac tradition.</p><span class="bv2-latest-read">Read article →</span></div></a>
    <a class="bv2-latest-card" href="blog/zodiac-compatibility-guide.html"><img src="images/guides/compatibility-guide.webp" alt="Zodiac compatibility and relationships" loading="lazy" width="440" height="260"><div class="bv2-latest-body"><p class="bv2-latest-kicker">Love &amp; Compatibility</p><h3>Most Compatible Zodiac Signs</h3><p>Explore traditional zodiac pairings for love, friendship, and long-term relationships.</p><span class="bv2-latest-read">Read article →</span></div></a>
    <a class="bv2-latest-card" href="blog/lucky-days-opening-business.html"><img src="images/guides/opening-day-card.webp" alt="Choosing an auspicious day to open a business" loading="lazy" width="440" height="260"><div class="bv2-latest-body"><p class="bv2-latest-kicker">Traditional Guidance</p><h3>How to Choose a Lucky Business Opening Day</h3><p>Discover Cambodian traditions for choosing a meaningful date for a new beginning.</p><span class="bv2-latest-read">Read article →</span></div></a>
    <a class="bv2-latest-card" href="blog/khmer-lunar-calendar-birth-date.html"><img src="images/guides/khmer-lunar-card.webp" alt="Angkor Wat beneath the moon, representing the Khmer lunar calendar" loading="lazy" width="440" height="260"><div class="bv2-latest-body"><p class="bv2-latest-kicker">Khmer Culture</p><h3>Understanding the Khmer Lunar Calendar</h3><p>Learn about waxing and waning moon days and finding your Khmer lunar birth date.</p><span class="bv2-latest-read">Read article →</span></div></a>
  </div>
</section>
''',
    "km": '''<section class="bv2-section bv2-latest-section" id="latest-articles">
  <div class="bv2-section-head">
    <h2>អត្ថបទថ្មីៗ</h2>
    <a class="bv2-view-all" href="blog.html">មើលអត្ថបទទាំងអស់ →</a>
  </div>
  <div class="bv2-latest-grid">
    <a class="bv2-latest-card" href="blog/five-elements-explained.html"><img src="images/guides/five-elements.webp" alt="ធាតុទាំងប្រាំក្នុងប្រពៃណីរាសីចិន" loading="lazy" width="440" height="260"><div class="bv2-latest-body"><p class="bv2-latest-kicker">មូលដ្ឋានរាសី</p><h3>ធាតុទាំងប្រាំក្នុងរាសីចិន</h3><p>ស្វែងយល់អំពីធាតុឈើ ភ្លើង ដី លោហៈ និងទឹកក្នុងប្រពៃណីរាសី។</p><span class="bv2-latest-read">អានអត្ថបទ →</span></div></a>
    <a class="bv2-latest-card" href="blog/zodiac-compatibility-guide.html"><img src="images/guides/compatibility-guide.webp" alt="ភាពសមស្របនៃរាសី និងទំនាក់ទំនង" loading="lazy" width="440" height="260"><div class="bv2-latest-body"><p class="bv2-latest-kicker">ស្នេហា និងភាពសមស្រប</p><h3>រាសីដែលសមស្របគ្នាបំផុត</h3><p>ស្វែងយល់ពីគូរាសីតាមប្រពៃណីសម្រាប់ស្នេហា មិត្តភាព និងទំនាក់ទំនងយូរអង្វែង។</p><span class="bv2-latest-read">អានអត្ថបទ →</span></div></a>
    <a class="bv2-latest-card" href="blog/lucky-days-opening-business.html"><img src="images/guides/opening-day-card.webp" alt="ការជ្រើសរើសថ្ងៃសមរម្យសម្រាប់បើកអាជីវកម្ម" loading="lazy" width="440" height="260"><div class="bv2-latest-body"><p class="bv2-latest-kicker">ការណែនាំតាមប្រពៃណី</p><h3>របៀបជ្រើសរើសថ្ងៃបើកអាជីវកម្ម</h3><p>ស្វែងយល់ពីប្រពៃណីខ្មែរក្នុងការជ្រើសរើសថ្ងៃសម្រាប់ការចាប់ផ្តើមថ្មី។</p><span class="bv2-latest-read">អានអត្ថបទ →</span></div></a>
    <a class="bv2-latest-card" href="blog/khmer-lunar-calendar-birth-date.html"><img src="images/guides/khmer-lunar-card.webp" alt="អង្គរវត្តក្រោមពន្លឺព្រះចន្ទ តំណាងឱ្យប្រតិទិនចន្ទគតិខ្មែរ" loading="lazy" width="440" height="260"><div class="bv2-latest-body"><p class="bv2-latest-kicker">វប្បធម៌ខ្មែរ</p><h3>ស្វែងយល់អំពីប្រតិទិនចន្ទគតិខ្មែរ</h3><p>ស្វែងយល់ពីថ្ងៃកើត ថ្ងៃរោច និងរបៀបរកថ្ងៃខែកំណើតតាមចន្ទគតិខ្មែរ។</p><span class="bv2-latest-read">អានអត្ថបទ →</span></div></a>
  </div>
</section>
''',
    "zh": '''<section class="bv2-section bv2-latest-section" id="latest-articles">
  <div class="bv2-section-head">
    <h2>最新文章</h2>
    <a class="bv2-view-all" href="blog.html">查看全部文章 →</a>
  </div>
  <div class="bv2-latest-grid">
    <a class="bv2-latest-card" href="blog/five-elements-explained.html"><img src="images/guides/five-elements.webp" alt="中国生肖传统中的五行" loading="lazy" width="440" height="260"><div class="bv2-latest-body"><p class="bv2-latest-kicker">生肖基础</p><h3>中国生肖中的五行</h3><p>了解木、火、土、金、水如何为生肖传统增添另一层含义。</p><span class="bv2-latest-read">阅读文章 →</span></div></a>
    <a class="bv2-latest-card" href="blog/zodiac-compatibility-guide.html"><img src="images/guides/compatibility-guide.webp" alt="生肖配对与人际关系" loading="lazy" width="440" height="260"><div class="bv2-latest-body"><p class="bv2-latest-kicker">爱情与配对</p><h3>最合拍的生肖组合</h3><p>探索传统生肖配对在爱情、友谊和长期关系中的意义。</p><span class="bv2-latest-read">阅读文章 →</span></div></a>
    <a class="bv2-latest-card" href="blog/lucky-days-opening-business.html"><img src="images/guides/opening-day-card.webp" alt="选择适合开业的吉日" loading="lazy" width="440" height="260"><div class="bv2-latest-body"><p class="bv2-latest-kicker">传统指南</p><h3>如何选择开业吉日</h3><p>了解柬埔寨传统中为事业新起点选择有意义日期的方式。</p><span class="bv2-latest-read">阅读文章 →</span></div></a>
    <a class="bv2-latest-card" href="blog/khmer-lunar-calendar-birth-date.html"><img src="images/guides/khmer-lunar-card.webp" alt="月光下的吴哥窟，代表高棉阴历" loading="lazy" width="440" height="260"><div class="bv2-latest-body"><p class="bv2-latest-kicker">高棉文化</p><h3>了解高棉阴历</h3><p>认识月亮盈亏日期，并了解如何查找自己的高棉阴历生日。</p><span class="bv2-latest-read">阅读文章 →</span></div></a>
  </div>
</section>
'''
}

# Inject one translated Latest Articles section in each existing language block before its info section.
for lang, snippet in LATEST.items():
    pattern = re.compile(r'(<div\s+data-lang-content="' + re.escape(lang) + r'">.*?)(?=\s*<section class="bv2-info-section">)', re.S)
    matches = list(pattern.finditer(html))
    if len(matches) != 1:
        if 'bv2-latest-section' in html:
            continue
        sys.exit(f"ERROR: Expected one {lang} section before .bv2-info-section; no changes written.")
    if 'bv2-latest-section' not in matches[0].group(1):
        pos = matches[0].end(1)
        translated_snippet = snippet.replace('id="latest-articles"', f'id="latest-articles-{lang}"')
        html = html[:pos] + "\n" + translated_snippet + html[pos:]

if html == original and CSS_TARGET.is_file():
    print("Already applied: no changes needed.")
    raise SystemExit(0)

# Validate structural counts before writes.
if html.count(link) != 1:
    sys.exit("ERROR: stylesheet link count is not one; no changes written.")
if html.count('bv2-latest-section') != 3:
    sys.exit("ERROR: expected exactly three translated Latest Articles sections; no changes written.")

CSS_TARGET.parent.mkdir(parents=True, exist_ok=True)
CSS_TARGET.write_text(CSS_SOURCE.read_text(encoding="utf-8"), encoding="utf-8")
BLOG.write_text(html, encoding="utf-8")
print("Applied blog redesign:")
print(" - blog.html: page-specific CSS link + Latest Articles in EN/KM/ZH")
print(" - css/blog-polish.css: visual styling scoped to the blog landing page")
print(" - No other files changed by this script")
