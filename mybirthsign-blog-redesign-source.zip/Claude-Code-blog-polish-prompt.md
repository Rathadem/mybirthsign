# Apply MyBirthSign blog redesign safely

Repository: `Rathadem/mybirthsign`

The user wants the blog landing page to match the supplied premium visual: deep midnight navy, restrained purple, gold accents, cinematic Angkor-inspired image hero, editorial cards, 12 zodiac tiles, and a Latest Articles row.

## Mandatory safety
- Work only on a separate branch named `blog-polish-preview` based on latest `main`.
- Do not edit `main`, merge, publish production, change DNS, or trigger a production deploy.
- Only change `blog.html` and add `css/blog-polish.css`.
- Do not modify article content/pages, calculators, daily fortune generation, global CSS, Netlify functions, AdSense scripts, analytics, or SEO metadata.

## Implementation
1. Copy `blog-polish.css` and `apply_blog_redesign.py` to the repository root.
2. Run `python apply_blog_redesign.py` from the repository root. The script adds the page-specific stylesheet link and one translated Latest Articles section in each existing `en`, `km`, and `zh` block, and creates `css/blog-polish.css`.
3. Check `git diff`. Confirm the `<head>` canonical, Open Graph, description, AdSense code, daily favicon script and main navigation did not change. Confirm only `blog.html` and `css/blog-polish.css` are changed.
4. Run `node scripts/build-site.mjs` and existing tests that are appropriate for a static page change. Inspect generated `dist/blog.html`, `dist/km/blog.html`, and `dist/zh/blog.html`.
5. Check at desktop, tablet, 390px and 320px. Ensure the hero text is readable, the cards do not overflow, EN/KM/ZH language links work, and the article links exist.
6. If a Netlify preview is actually created, share its URL and state which checks passed. Do not create or claim a production deployment.

## Image paths and links
The new stylesheet uses `images/guides/khmer-lunar-wide.webp`; article cards use existing images under `images/guides/` and existing blog URLs. Do not generate fake article content or URLs.
